import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class Test {


    public static void main(String[] args) {
        String line;

        try {

            BufferedReader rd=new BufferedReader(new FileReader("C:\\Users\\KZ33\\Desktop\\TestFile.txt"));
            BufferedWriter rw=new BufferedWriter(new FileWriter("C:\\Users\\KZ33\\Desktop\\WrittenTestFile.txt"));

            Map<String,String> t=new HashMap<String,String>();

            while(((line = rd.readLine()) != null)){
                String[] parts = line.split("");
                String keys = parts[0];
                //String value = parts[1];
                t.put(keys, line);
                for (String key : t.keySet())
                {
                    System.out.println(t.get(key));
                    rw.write(t.get(key));
                }


            }

            rd.close();
            rw.close();


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}
