package contra;


import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class App {

    public static void main(String[] args) throws DocumentException , IOException, InterruptedException {
        String line;
        Document document = new Document();



            FileReader fileReader = new FileReader("C:\\Users\\KZ33\\Desktop\\New.txt");
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            PdfWriter.getInstance(document, new FileOutputStream("C:\\Users\\KZ33\\Desktop\\Mario-1.pdf"));
            document.open();
            Font font = FontFactory.getFont(FontFactory.TIMES_ROMAN, 4, BaseColor.BLACK);

            //String header = "pdfHtml Header and footer example using page-events";
             //Header headerHandler = new Header(header);

           //PdfWriter.addEventHandler(PdfDocumentEvent.START_PAGE,headerHandler);

        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
        Date date = new Date();
        String s=formatter.format(date);
        System.out.println(s);

        Paragraph p1=new Paragraph();
            Paragraph p2=new Paragraph();
            Paragraph p3=new Paragraph();
        Paragraph p4=new Paragraph();
            p2.setAlignment(Element.ALIGN_CENTER);
            p1.setAlignment(Element.ALIGN_CENTER);
            p3.setAlignment(Element.ALIGN_CENTER);
            p4.setAlignment(Element.ALIGN_LEFT);





            Chunk c=new Chunk("AEB/AEB-NY/UDC");
            Chunk c1=new Chunk( "COMPASS/CZ COMMISSIONS GENERAL LEDGER SUMMARY REPORT");
            Chunk c2=new Chunk("CYCLE DATE:" + s);;
            //Chunk c3= new Chunk("RUN DATE :" + s);

            p2.add(c);
            p1.add(c1);
            p3.add(c2);
            //p4.add(c3);

            document.add(p2);
            //document.add(Chunk.NEWLINE);
            document.add(p1);
        //document.add(p4);
            document.add(p3);

            document.add(Chunk.NEWLINE);

            document.close();







    }
}
