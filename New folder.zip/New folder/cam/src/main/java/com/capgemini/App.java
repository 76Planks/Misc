package com.capgemini;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPage;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;


public class App {
    public static void main(String[] args) throws DocumentException {

        DateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        DateFormat sdf2=new SimpleDateFormat("HH:mm");


        String line;
        Document document = new Document();
        int count = 0;
        Date date=new Date();
        try {

            FileReader fileReader = new FileReader("C:\\Users\\KZ33\\Desktop\\New.txt");
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            PdfWriter.getInstance(document, new FileOutputStream("C:\\Users\\KZ33\\Desktop\\test12.pdf"));
            Font font = FontFactory.getFont(FontFactory.TIMES_ROMAN, 8, BaseColor.BLACK);
            document.open();
            while ((line = bufferedReader.readLine()) != null) {
                if (count == 0) {

                    Chunk chunk = new Chunk(line, font);
                    document.add(Chunk.NEWLINE);
                    Phrase phrase = new Phrase();
                    phrase.add(chunk);
                    document.add(phrase);
                    count++;
                }
                    else if(count==1){
                    line=line.replace(line.substring(10,20),sdf.format(date));
                    Chunk chunk = new Chunk(line, font);
                    document.add(Chunk.NEWLINE);
                    Phrase phrase = new Phrase();
                    phrase.add(chunk);
                    document.add(phrase);
                    count++;

                    }
                else if (count==2) {
                    System.out.println(line.indexOf("TE"));
                    line = line.replace(line.substring(10, 20), sdf2.format(date));
                    line=line.replace(line.substring(79,89),sdf.format(date));
                    Chunk chunk = new Chunk(line, font);
                    document.add(Chunk.NEWLINE);
                    Phrase phrase = new Phrase();
                    phrase.add(chunk);
                    document.add(phrase);
                    count++;
                }
                    else{
                    Chunk chunk = new Chunk(line, font);
                    document.add(Chunk.NEWLINE);
                    Phrase phrase = new Phrase();
                    //Paragraph p=new Paragraph(line);
                    phrase.add(chunk);
                    document.add(phrase);
                    // document.add(new Paragraph());
                    //document.add( Chunk.NEWLINE );

                }



                }

                document.close();


            }

        catch(FileNotFoundException ex){
                System.out.println(ex);
            } catch(IOException ex){
                System.out.println(ex);
                ;
            }


        }
    }


