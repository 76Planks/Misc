package cap.com;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

public class App {
	public static void main(String[] args) throws DocumentException {

		String line;
		Document document = new Document();

		try {

			FileReader fileReader = new FileReader("C:\\Users\\Prashant\\Desktop\\test.txt");
			BufferedReader bufferedReader = new BufferedReader(fileReader);

			PdfWriter.getInstance(document, new FileOutputStream("C:\\Users\\Prashant\\Desktop\\test1234.pdf"));
			document.open();
			Font font = FontFactory.getFont(FontFactory.COURIER, 10, BaseColor.BLACK);

			while ((line = bufferedReader.readLine()) != null) {
				System.out.println(line);
				Chunk chunk = new Chunk(line);
				document.add(chunk);
				// document.add(new Paragraph());
				// document.add( Chunk.NEWLINE );

			}
			document.close();

		}

		catch (FileNotFoundException ex) {
			System.out.println(ex);
		} catch (IOException ex) {
			System.out.println(ex);
			;
		}
	}
}
