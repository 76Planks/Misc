package com;

import com.itextpdf.kernel.color.Color;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.pdf.canvas.PdfCanvas;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.border.Border;
import com.itextpdf.layout.border.SolidBorder;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.property.TextAlignment;
import com.itextpdf.layout.property.UnitValue;
import com.itextpdf.text.*;
import com.itextpdf.text.Font;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;

import java.awt.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.StringTokenizer;

public class App {
    public static final String DATA = "C:\\Users\\KZ33\\Desktop\\New.txt";

    public static final String DEST = "C:\\Users\\KZ33\\Desktop\\Tabletry.pdf";

    public static void main(String[] args) throws IOException {
        File file = new File(DEST);
        file.getParentFile().mkdirs();
        new App().createPdf(DEST);

    }

    public void createPdf(String dest) throws IOException {
        //Initialize PDF writer
        PdfWriter writer = new PdfWriter(dest);

        //Initialize PDF document
        PdfDocument pdf = new PdfDocument(writer);

        // Initialize document
        Document document = new Document(pdf, PageSize.A4.rotate());
        DateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        DateFormat sdf2=new SimpleDateFormat("HH:mm");
        Date date=new Date();
        document.setMargins(20, 20, 20, 20);
        Paragraph p = new Paragraph("PGM CZPPGLD"+"                                                     " +"AEB/AEB-NY/UDC" +"                                     "+"REPORT ID:CZGENLGR")
             /*.setTextAlignment(TextAlignment.CENTER)*/.setFontSize(14);
        document.add(p);
        Paragraph p1 = new Paragraph("RUN DATE :"+sdf.format(date)+"                      "+"COMPASS/CZ COMMISSIONS GENERAL LEDGER SUMMARY REPORT");
        document.add(p1);
        Paragraph p2 = new Paragraph("RUN TIME :"+sdf2.format(date)+"                                                              "+"CYCLE DATE:"+sdf.format(date));
        document.add(p2);
        //PdfFont font = PdfFontFactory.createFont(StandardFonts.HELVETICA);
        //PdfFont bold = PdfFontFactory.createFont(StandardFonts.HELVETICA_BOLD);
        Font font = com.itextpdf.text.FontFactory.getFont(FontFactory.TIMES_ROMAN, 8, BaseColor.BLACK);
        Table table = new Table(UnitValue.createPercentArray(new float[]{4, 4, 4, 4, 2, 3, 3,}))
                .useAllAvailableWidth();
        table.setPadding(0);
        table.setSpacingRatio(5);

        PdfPTable pTable=new PdfPTable(new float[]{4, 4, 4, 4, 2, 3, 3,});
        //pTable.getDefaultCell().setBorder(0);


        //table.setBackgroundColor(Color.WHITE,05);
        BufferedReader br = new BufferedReader(new FileReader(DATA));
        String line = br.readLine();
        process(table, line, font, true);
        while ((line = br.readLine()) != null) {
            process(table, line, font, false);
        }
        br.close();
        document.add(table);

        //Close document
        document.close();
    }
    public void process(Table table, String line, Font font, boolean isHeader) {
        StringTokenizer tokenizer = new StringTokenizer(line,"_");
        while (tokenizer.hasMoreTokens()) {
            if (isHeader) {
                table.addHeaderCell(new Cell().add(new Paragraph(tokenizer.nextToken())));
                //table.addCell(new PdfPCell(new Phrase(tokenizer.nextToken())));
            } else {
                table.addCell(new Cell().add(new Paragraph(tokenizer.nextToken()).setBorder(Border.NO_BORDER)));
                //table.addCell(new Phrase(tokenizer.nextToken()));
            }
        }
    }

}


